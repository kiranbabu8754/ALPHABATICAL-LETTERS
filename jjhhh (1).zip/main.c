/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main()
{
   int n,a,i=0,c=1,d=0;
   scanf("%d",&n);
   a=n;
   while(n>0)
   {
       n=n/10;
       i++;
   }
   i=i-1;
   while(i>0)
   {
     c=c*10;
     i--;
   }
   int rem=a%10;
   int e=a/c;
   d=rem+e;
   printf("%d",d);
       return 0;
}